//
//  PortException.h
//  StarIOPort
//

#ifndef PortException_h
#define PortException_h

#import <Foundation/Foundation.h>

@interface PortException : NSException

@end

#endif /* PortException_h */
