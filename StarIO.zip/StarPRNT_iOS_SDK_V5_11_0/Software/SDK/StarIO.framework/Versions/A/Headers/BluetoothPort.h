//
//  BluetoothPort.h
//  StarIOPort
//
//  Created by u3237 on 2017/03/09.
//
//

#import "ExternalAccessoryPort.h"
#import "Util.h"

@interface BluetoothPort : ExternalAccessoryPort

@end
