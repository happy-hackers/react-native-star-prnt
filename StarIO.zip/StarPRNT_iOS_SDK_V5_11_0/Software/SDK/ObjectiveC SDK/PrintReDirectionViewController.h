//
//  PrintReDirectionViewController.h
//  ObjectiveC SDK
//
//  Copyright (c) 2018 Star Micronics. All rights reserved.
//

#import "PrinterViewController.h"

@interface PrintReDirectionViewController : PrinterViewController

@end
