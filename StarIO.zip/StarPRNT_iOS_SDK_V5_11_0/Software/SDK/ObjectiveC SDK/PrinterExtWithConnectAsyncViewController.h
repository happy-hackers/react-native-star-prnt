//
//  PrinterExtWithConnectAsyncViewController.h
//  ObjectiveC SDK
//
//  Copyright (c) 2018 Star Micronics. All rights reserved.
//

#import "PrinterExtViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PrinterExtWithConnectAsyncViewController : PrinterExtViewController

@end

NS_ASSUME_NONNULL_END
