//
//  ISCPConnectParser.h
//  StarIO_Extension
//
//  Created by Yuji on 2017/**/**.
//  Copyright © 2017年 Star Micronics. All rights reserved.
//

#import "ISCPParser.h"

@interface ISCPConnectParser : ISCPParser

- (BOOL)connect;

@end
